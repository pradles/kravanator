import { Spline } from "./Spline.mjs"

var i=0
var points = []
var curves = []

function points_push(x,y){
        points.push([x,y])
}

function curves_push(){
    curves.push(points)
    points = []
}

window.narisi = function(){
    const spline = new Spline(curves);
    spline.makeContinuous();
    var curves2 = spline.makeSmooth();
    curves2.forEach(element => {
        izrisi(element)
    });   
    curves = []

}

window.onload = function(){
    var canvas = document.getElementById("can")
    canvas.width = window.innerWidth*0.9
    canvas.height = window.innerHeight*0.9
}

function getCursorPosition(canvas, event) {
    const rect = canvas.getBoundingClientRect()
    const ctx = canvas.getContext('2d')
    const x = event.clientX - rect.left
    const y = event.clientY - rect.top

    if(i==3 || i==0){
        ctx.beginPath()
        ctx.arc(x,y, 5,0, 2 * Math.PI)
        ctx.fillStyle = 'orange'
        ctx.fill()
    }
    else{
        ctx.fillStyle = 'blue';
        ctx.fillRect(x - 10 / 2, y - 10 / 2, 10, 10); 
    }

    if(i==3){
        points_push(x,y)
        curves_push(x,y)
        i=0;
    }
    else{
        points_push(x,y)
        i++;
    }
    
    //console.log("x: " + x + " y: " + y)
}

var canvas = document.getElementById("can")
canvas.addEventListener("mousedown", function (e) 
{ getCursorPosition(canvas, e);})


//return x,y na casu t
window.bezier = function(t, p0, p1, p2, p3){
    var cX = 3 * (p1[0] - p0[0]),
        bX = 3 * (p2[0] - p1[0]) - cX,
        aX = p3[0] - p0[0] - cX - bX
          
    var cY = 3 * (p1[1] - p0[1]),
        bY = 3 * (p2[1] - p1[1]) - cY,
        aY = p3[1] - p0[1] - cY - bY
          
    var x = (aX * Math.pow(t, 3)) + (bX * Math.pow(t, 2)) + (cX * t) + p0[0]
    var y = (aY * Math.pow(t, 3)) + (bY * Math.pow(t, 2)) + (cY * t) + p0[1]
          
    return {x: x, y: y};
}


window.izrisi = function(tocke){
    var canvas = document.getElementById("can")
    const ctx2 = canvas.getContext('2d')
    var tocnost = 0.001, 
        p0 = tocke[0],
        p1 = tocke[1],
        p2 = tocke[2],
        p3 = tocke[3]
    ctx2.moveTo(p0[0], p0[1]);
    for (var i=0; i<1; i+=tocnost){
       var p = bezier(i, p0, p1, p2, p3)
       ctx2.lineTo(p.x, p.y)
    }
    ctx2.stroke()
}

  

